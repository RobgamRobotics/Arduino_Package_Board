#include "wiring_private.h"

#define M1A 5
#define M2A 6

#define M1B 9
#define M2B 10

void INIT_LEDS()
{
	pinMode(LED_1, OUTPUT);
	pinMode(LED_2, OUTPUT);
	pinMode(LED_3, OUTPUT);
	pinMode(LED_4, OUTPUT);
	pinMode(LED_5, OUTPUT);
}


void LED_1_WRITE(bool estatus)
{
	if(estatus == 1) digitalWrite(LED_1, HIGH);
	else if(estatus == 0) digitalWrite(LED_1, LOW);
}

void LED_2_WRITE(bool estatus)
{
	if(estatus == 1) digitalWrite(LED_2, HIGH);
	else if(estatus == 0) digitalWrite(LED_2, LOW);
}

void LED_3_WRITE(bool estatus)
{
	if(estatus == 1) digitalWrite(LED_3, HIGH);
	else if(estatus == 0) digitalWrite(LED_3, LOW);
}

void LED_4_WRITE(bool estatus)
{
	if(estatus == 1) digitalWrite(LED_4, HIGH);
	else if(estatus == 0) digitalWrite(LED_4, LOW);
}

void LED_5_WRITE(bool estatus)
{
	if(estatus == 1) digitalWrite(LED_5, HIGH);
	else if(estatus == 0) digitalWrite(LED_5, LOW);
}





void SERVO_1(uint8_t val)
{
	analogWrite(9, val);
}

void SERVO_2(uint8_t val)
{
	analogWrite(10, val);
}

void SERVO_3(uint8_t val)
{
	analogWrite(5, val);
}

void SERVO_4(uint8_t val)
{
	analogWrite(6, val);
}




void INIT_MOTORS()
{
	pinMode(M1A, OUTPUT);
	pinMode(M2A, OUTPUT);

	pinMode(M1B, OUTPUT);
	pinMode(M2B, OUTPUT);
}


void MOTOR_1(bool dir, uint8_t vel)
{
	if (dir == ADELANTE)
	{
		analogWrite(M1A, vel);
		digitalWrite(M2A, LOW);
	}
	
	if (dir == ATRAS)
	{
		analogWrite(M2A, vel);
		digitalWrite(M1A, LOW);
	}
}

void MOTOR_2(bool dir, uint8_t vel)
{
	if (dir == ADELANTE)
	{
		analogWrite(M1B, vel);
		digitalWrite(M2B, LOW);
	}

	if (dir == ATRAS)
	{
		analogWrite(M2B, vel);
		digitalWrite(M1B, LOW);
	}
}