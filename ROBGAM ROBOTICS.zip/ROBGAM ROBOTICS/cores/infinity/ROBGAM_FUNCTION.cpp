#include "wiring_private.h"

#define M1A 	7
#define M2A 	6
#define PWMA 	5

#define M1B 	9
#define M2B 	8
#define PWMB	10

void INIT_LEDS()
{
	pinMode(LED_1, OUTPUT);
	pinMode(LED_2, OUTPUT);
	pinMode(LED_3, OUTPUT);
}


void LED_1_WRITE(bool estatus)
{
	if(estatus == 1) digitalWrite(LED_1, HIGH);
	else if(estatus == 0) digitalWrite(LED_1, LOW);
}

void LED_2_WRITE(bool estatus)
{
	if(estatus == 1) digitalWrite(LED_2, HIGH);
	else if(estatus == 0) digitalWrite(LED_2, LOW);
}

void LED_3_WRITE(bool estatus)
{
	if(estatus == 1) digitalWrite(LED_3, HIGH);
	else if(estatus == 0) digitalWrite(LED_3, LOW);
}




void INIT_MOTORS()
{
	pinMode(M1A, OUTPUT);
	pinMode(M2A, OUTPUT);

	pinMode(M1B, OUTPUT);
	pinMode(M2B, OUTPUT);
}


void MOTOR_1(bool dir, uint8_t vel)
{
	if (dir == ADELANTE)
	{
		digitalWrite(M1A, HIGH);
		digitalWrite(M2A, LOW);
		analogWrite(PWMA, vel);
	}
	
	if (dir == ATRAS)
	{
		digitalWrite(M2A, HIGH);
		digitalWrite(M1A, LOW);
		analogWrite(PWMA, vel);
	}
}

void MOTOR_2(bool dir, uint8_t vel)
{
	if (dir == ADELANTE)
	{
		digitalWrite(M1B, HIGH);
		digitalWrite(M2B, LOW);
		analogWrite(PWMB, vel);
	}

	if (dir == ATRAS)
	{
		digitalWrite(M2B, HIGH);
		digitalWrite(M1B, LOW);
		analogWrite(PWMB, vel);
	}
}